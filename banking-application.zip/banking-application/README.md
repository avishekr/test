# Banking-Application

It is an online banking application designed in a simple and scalar way to handle more or less all the activities that is included in a bank.

It was made using Spring Boot, Spring Security, Thymeleaf, Spring Data JPA, Spring Data REST, JavaScript, JQuery. Database is in memory SQL.

Online Banking Requirements

It is designed in such a way where there are two parts one is admin role specific and one is user specific. The user role specific requirements include the sign up, sign in for a registered user and also the deposit withdraw facilities. Admin role model is mainly used for the appointment of the customers and maintaining the accounts of customers from the banks perspective.
